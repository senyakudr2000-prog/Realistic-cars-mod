package com.realcars;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class RealCarsMod implements ModInitializer {
    public static final String MOD_ID = "realcars";

    public static EntityType<CarEntity> CAR;
    public static Item CAR_ITEM;

    @Override
    public void onInitialize() {
        CAR = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "car"),
                EntityType.Builder.<CarEntity>create(CarEntity::new, SpawnGroup.MISC)
                        .dimensions(2.4f, 2.0f)
                        .maxTrackingRange(10)
                        .trackingTickInterval(1)
                        .build("car"));

        CAR_ITEM = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "car"),
                new CarItem(new Item.Settings().maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(CAR_ITEM));

        PayloadTypeRegistry.playC2S().register(CarInputPayload.ID, CarInputPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CarInputPayload.ID, (payload, context) -> {
            var player = context.player();
            if (player.getVehicle() instanceof CarEntity car && car.getFirstPassenger() == player) {
                car.setInput(payload.throttle(), payload.steer(), payload.brake());
            }
        });
    }
}
