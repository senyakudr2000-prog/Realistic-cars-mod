package com.realcars;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CarItem extends Item {
    private static final int[] COLORS = {0xC62828, 0x1565C0, 0xF9A825, 0x2E7D32, 0xEEEEEE, 0x212121, 0x6A1B9A, 0xEF6C00};

    public CarItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        if (!(world instanceof ServerWorld)) return ActionResult.SUCCESS;

        BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
        CarEntity car = RealCarsMod.CAR.create(world);
        if (car == null) return ActionResult.FAIL;

        PlayerEntity player = ctx.getPlayer();
        car.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5,
                player != null ? player.getYaw() : 0f, 0f);
        if (!world.isSpaceEmpty(car)) return ActionResult.FAIL;

        car.setColor(COLORS[world.random.nextInt(COLORS.length)]);
        world.spawnEntity(car);
        if (player == null || !player.getAbilities().creativeMode) ctx.getStack().decrement(1);
        return ActionResult.CONSUME;
    }
}
