package com.realcars;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: driver input (throttle -1..1, steer -1..1 where +1 = left, handbrake). */
public record CarInputPayload(float throttle, float steer, boolean brake) implements CustomPayload {
    public static final CustomPayload.Id<CarInputPayload> ID =
            new CustomPayload.Id<>(Identifier.of(RealCarsMod.MOD_ID, "car_input"));

    public static final PacketCodec<RegistryByteBuf, CarInputPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.FLOAT, CarInputPayload::throttle,
            PacketCodecs.FLOAT, CarInputPayload::steer,
            PacketCodecs.BOOL, CarInputPayload::brake,
            CarInputPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
