package com.realcars.client;

import com.realcars.CarEntity;
import com.realcars.CarMesh;
import com.realcars.RealCarsMod;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class CarRenderer extends EntityRenderer<CarEntity> {
    private static final Identifier BODY_TEX = Identifier.of(RealCarsMod.MOD_ID, "textures/entity/car_body.png");
    private static final Identifier GLASS_TEX = Identifier.of(RealCarsMod.MOD_ID, "textures/entity/car_glass.png");
    private static final Identifier CRACKED_TEX = Identifier.of(RealCarsMod.MOD_ID, "textures/entity/car_glass_cracked.png");

    public CarRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 1.1f;
    }

    @Override
    public Identifier getTexture(CarEntity entity) {
        return BODY_TEX;
    }

    @Override
    public void render(CarEntity car, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light) {
        float[] pos = car.getDeformedMesh();
        int color = car.getColor();
        int cr = (color >> 16) & 255, cg = (color >> 8) & 255, cb = color & 255;

        m.push();
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-MathHelper.lerpAngleDegrees(tickDelta, car.prevYaw, car.getYaw())));

        // pass 1: opaque body, trim, lights, wheels
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(BODY_TEX));
        MatrixStack.Entry e = m.peek();
        for (int q = 0; q < CarMesh.QUADS; q++) {
            int part = CarMesh.PART[q];
            if (part >= CarMesh.WIN_FRONT && part <= CarMesh.WIN_RIGHT) continue;
            int r = cr, g = cg, b = cb, l = light;
            switch (part) {
                case CarMesh.TRIM -> { r = 35; g = 35; b = 40; }
                case CarMesh.HEADLIGHT -> { r = 255; g = 245; b = 210; l = LightmapTextureManager.MAX_LIGHT_COORDINATE; }
                case CarMesh.TAILLIGHT -> { r = 230; g = 25; b = 25; l = LightmapTextureManager.MAX_LIGHT_COORDINATE; }
                default -> { }
            }
            emit(vc, e, pos, q, r, g, b, 255, l);
        }
        float spin = MathHelper.lerp(tickDelta, car.prevWheelAngle, car.wheelAngle);
        float steer = MathHelper.lerp(tickDelta, car.prevSteerVis, car.steerVis);
        wheel(vc, m, 0.78f, 0.34f, 1.15f, spin, steer, light);
        wheel(vc, m, -0.78f, 0.34f, 1.15f, spin, steer, light);
        wheel(vc, m, 0.78f, 0.34f, -1.15f, spin, 0f, light);
        wheel(vc, m, -0.78f, 0.34f, -1.15f, spin, 0f, light);

        // pass 2: intact glass
        vc = vcp.getBuffer(RenderLayer.getEntityTranslucent(GLASS_TEX));
        e = m.peek();
        for (int q = 0; q < CarMesh.QUADS; q++) {
            int part = CarMesh.PART[q];
            if (part < CarMesh.WIN_FRONT || part > CarMesh.WIN_RIGHT) continue;
            if (car.getGlassLevel(part - 1) == 0) emit(vc, e, pos, q, 255, 255, 255, 255, light);
        }

        // pass 3: cracked glass (level 2 = shattered, not drawn)
        vc = vcp.getBuffer(RenderLayer.getEntityTranslucent(CRACKED_TEX));
        e = m.peek();
        for (int q = 0; q < CarMesh.QUADS; q++) {
            int part = CarMesh.PART[q];
            if (part < CarMesh.WIN_FRONT || part > CarMesh.WIN_RIGHT) continue;
            if (car.getGlassLevel(part - 1) == 1) emit(vc, e, pos, q, 255, 255, 255, 255, light);
        }

        m.pop();
        super.render(car, yaw, tickDelta, m, vcp, light);
    }

    /** Emits one deformed quad with a flat normal recomputed from the dented vertices. */
    private static void emit(VertexConsumer vc, MatrixStack.Entry e, float[] pos, int q, int r, int g, int b, int a, int light) {
        int o = q * 12;
        float[] n = CarMesh.quadNormal(java.util.Arrays.copyOfRange(pos, o, o + 12));
        int rn = q * 3;
        if (n[0] * CarMesh.REST_NORMAL[rn] + n[1] * CarMesh.REST_NORMAL[rn + 1] + n[2] * CarMesh.REST_NORMAL[rn + 2] < 0) {
            n[0] = -n[0]; n[1] = -n[1]; n[2] = -n[2];
        }
        for (int k = 0; k < 4; k++) {
            vc.vertex(e, pos[o + k * 3], pos[o + k * 3 + 1], pos[o + k * 3 + 2])
                    .color(r, g, b, a)
                    .texture(CarMesh.UV[q * 8 + k * 2], CarMesh.UV[q * 8 + k * 2 + 1])
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(e, n[0], n[1], n[2]);
        }
    }

    private static void vert(VertexConsumer vc, MatrixStack.Entry e, float x, float y, float z,
                             int c, int light, float nx, float ny, float nz) {
        vc.vertex(e, x, y, z).color(c, c, c, 255).texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(e, nx, ny, nz);
    }

    private static void wheel(VertexConsumer vc, MatrixStack m, float cx, float cy, float cz, float spin, float steer, int light) {
        m.push();
        m.translate(cx, cy, cz);
        if (steer != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(steer));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(spin));
        MatrixStack.Entry e = m.peek();
        final int n = 12;
        final float radius = 0.34f, half = 0.12f;
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            float y0 = (float) Math.cos(a0) * radius, z0 = (float) Math.sin(a0) * radius;
            float y1 = (float) Math.cos(a1) * radius, z1 = (float) Math.sin(a1) * radius;
            float ny = (float) Math.cos((a0 + a1) / 2), nz = (float) Math.sin((a0 + a1) / 2);
            vert(vc, e, half, y0, z0, 30, light, 0, ny, nz);
            vert(vc, e, -half, y0, z0, 30, light, 0, ny, nz);
            vert(vc, e, -half, y1, z1, 30, light, 0, ny, nz);
            vert(vc, e, half, y1, z1, 30, light, 0, ny, nz);
            vert(vc, e, half, 0, 0, 120, light, 1, 0, 0);
            vert(vc, e, half, y0, z0, 120, light, 1, 0, 0);
            vert(vc, e, half, y1, z1, 120, light, 1, 0, 0);
            vert(vc, e, half, 0, 0, 120, light, 1, 0, 0);
            vert(vc, e, -half, 0, 0, 120, light, -1, 0, 0);
            vert(vc, e, -half, y1, z1, 120, light, -1, 0, 0);
            vert(vc, e, -half, y0, z0, 120, light, -1, 0, 0);
            vert(vc, e, -half, 0, 0, 120, light, -1, 0, 0);
        }
        m.pop();
    }
}
