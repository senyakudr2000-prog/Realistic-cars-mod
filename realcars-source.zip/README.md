# Real Cars (Fabric 1.21.1)

Drivable cars with crash deformation and breaking glass.

- Item: **Car** (Creative → Tools tab; also craftable: iron/glass pane/redstone/coal, see data/realcars/recipe/car.json).
- Place it on a block, **right-click** to get in. **Shift** = get out.
- **W / S** gas & brake/reverse, **A / D** steer, **Space** handbrake.
- Crash into walls/blocks/other cars: dents appear at the exact impact point, windows crack (then shatter) depending on speed.
- Repair: right-click the car with an **iron ingot** (smooths dents), with a **glass pane** (replaces windows).
- Break the car into an item: **Shift + punch** it.
- Low obstacles (1 block) are climbed automatically.
