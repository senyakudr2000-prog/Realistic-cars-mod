package com.realcars;

import java.util.ArrayList;
import java.util.List;

/**
 * Procedural car body built from subdivided quads. Local space: +Z = forward, +X = car's left, +Y = up.
 * Every vertex is displaced by a pure function of its rest position, so dents stay continuous across quads.
 */
public final class CarMesh {
    public static final int BODY = 0, WIN_FRONT = 1, WIN_REAR = 2, WIN_LEFT = 3, WIN_RIGHT = 4,
            HEADLIGHT = 5, TAILLIGHT = 6, TRIM = 7;
    public static final float HALF_W = 0.85f, HALF_L = 1.8f;

    private static final List<float[]> POS_L = new ArrayList<>();
    private static final List<float[]> UV_L = new ArrayList<>();
    private static final List<float[]> N_L = new ArrayList<>();
    private static final List<Integer> PART_L = new ArrayList<>();

    /** Centers of the 4 windows: front, rear, left, right. */
    public static final float[][] WINDOW_CENTER = new float[4][];
    public static final int QUADS;
    public static final float[] REST;
    public static final float[] UV;
    public static final float[] REST_NORMAL;
    public static final int[] PART;

    static {
        build();
        QUADS = POS_L.size();
        REST = new float[QUADS * 12];
        UV = new float[QUADS * 8];
        REST_NORMAL = new float[QUADS * 3];
        PART = new int[QUADS];
        for (int i = 0; i < QUADS; i++) {
            System.arraycopy(POS_L.get(i), 0, REST, i * 12, 12);
            System.arraycopy(UV_L.get(i), 0, UV, i * 8, 8);
            System.arraycopy(N_L.get(i), 0, REST_NORMAL, i * 3, 3);
            PART[i] = PART_L.get(i);
        }
    }

    private CarMesh() {
    }

    // ------------------------------------------------------------------ deformation

    public static float[] deform(List<Impact> impacts) {
        if (impacts.isEmpty()) return REST;
        float[] out = new float[REST.length];
        float[] d = new float[3];
        for (int i = 0; i < REST.length; i += 3) {
            displace(REST[i], REST[i + 1], REST[i + 2], impacts, d);
            out[i] = REST[i] + d[0];
            out[i + 1] = REST[i + 1] + d[1];
            out[i + 2] = REST[i + 2] + d[2];
        }
        return out;
    }

    private static void displace(float x, float y, float z, List<Impact> impacts, float[] out) {
        float ox = 0, oy = 0, oz = 0;
        for (Impact im : impacts) {
            float ddx = x - im.x, ddy = y - im.y, ddz = z - im.z;
            float d2 = ddx * ddx + ddy * ddy + ddz * ddz;
            float r = im.radius;
            if (d2 >= r * r) continue;
            float t = 1f - (float) Math.sqrt(d2) / r;
            float w = t * t * (3f - 2f * t);
            // crumple noise so the dent is not a perfect smooth bowl
            float n = (float) (Math.sin(x * 21.7f + y * 13.1f + im.seed * 3.7f) * Math.cos(z * 19.3f - y * 9.7f + im.seed));
            float amt = im.depth * w * (1f + 0.3f * n);
            ox += im.dx * amt;
            oy += im.dy * amt;
            oz += im.dz * amt;
        }
        out[0] = ox; out[1] = oy; out[2] = oz;
    }

    // ------------------------------------------------------------------ geometry building

    private static void build() {
        // lower body
        float[] b0 = v(0.85f, 0.30f, -1.80f), b1 = v(-0.85f, 0.30f, -1.80f), b2 = v(-0.85f, 0.30f, 1.80f), b3 = v(0.85f, 0.30f, 1.80f);
        float[] t0 = v(0.83f, 0.95f, -1.78f), t1 = v(-0.83f, 0.95f, -1.78f), t2 = v(-0.83f, 0.95f, 1.78f), t3 = v(0.83f, 0.95f, 1.78f);
        float[][][] lb = loft(b0, b1, b2, b3, t0, t1, t2, t3);
        for (float[][] f : lb) face(f, BODY, 0, 1, 0, 1, 0f, 0.22f);
        float[][] fr = lb[0], rr = lb[1];
        face(fr, TRIM, 0.28f, 0.72f, 0.20f, 0.52f, 0.012f, 0.14f);
        face(fr, TRIM, 0f, 1f, 0f, 0.17f, 0.014f, 0.22f);
        face(fr, HEADLIGHT, 0.06f, 0.26f, 0.55f, 0.88f, 0.012f, 0.12f);
        face(fr, HEADLIGHT, 0.74f, 0.94f, 0.55f, 0.88f, 0.012f, 0.12f);
        face(rr, TRIM, 0f, 1f, 0f, 0.17f, 0.014f, 0.22f);
        face(rr, TAILLIGHT, 0.05f, 0.32f, 0.55f, 0.88f, 0.012f, 0.12f);
        face(rr, TAILLIGHT, 0.68f, 0.95f, 0.55f, 0.88f, 0.012f, 0.12f);

        // cabin
        float[] cb0 = v(0.78f, 0.95f, -1.00f), cb1 = v(-0.78f, 0.95f, -1.00f), cb2 = v(-0.78f, 0.95f, 0.90f), cb3 = v(0.78f, 0.95f, 0.90f);
        float[] ct0 = v(0.70f, 1.95f, -0.78f), ct1 = v(-0.70f, 1.95f, -0.78f), ct2 = v(-0.70f, 1.95f, 0.30f), ct3 = v(0.70f, 1.95f, 0.30f);
        float[][][] cab = loft(cb0, cb1, cb2, cb3, ct0, ct1, ct2, ct3);
        for (int k = 0; k < 5; k++) face(cab[k], BODY, 0, 1, 0, 1, 0f, 0.22f);
        face(cab[0], WIN_FRONT, 0.07f, 0.93f, 0.10f, 0.88f, 0.012f, 0.22f);
        face(cab[1], WIN_REAR, 0.10f, 0.90f, 0.15f, 0.85f, 0.012f, 0.22f);
        face(cab[2], WIN_LEFT, 0.06f, 0.47f, 0.14f, 0.86f, 0.012f, 0.22f);
        face(cab[2], WIN_LEFT, 0.53f, 0.94f, 0.14f, 0.86f, 0.012f, 0.22f);
        face(cab[3], WIN_RIGHT, 0.06f, 0.47f, 0.14f, 0.86f, 0.012f, 0.22f);
        face(cab[3], WIN_RIGHT, 0.53f, 0.94f, 0.14f, 0.86f, 0.012f, 0.22f);
        for (int k = 0; k < 4; k++) WINDOW_CENTER[k] = avg(cab[k][0], cab[k][1], cab[k][2], cab[k][3]);
    }

    /** Faces: 0 front, 1 rear, 2 left(+X), 3 right(-X), 4 top, 5 bottom. Each = 4 corners + outward hint. */
    private static float[][][] loft(float[] b0, float[] b1, float[] b2, float[] b3, float[] t0, float[] t1, float[] t2, float[] t3) {
        float[] ctr = avg(b0, b1, b2, b3, t0, t1, t2, t3);
        float[][][] f = new float[6][][];
        f[0] = new float[][]{b3, b2, t2, t3, null};
        f[1] = new float[][]{b1, b0, t0, t1, null};
        f[2] = new float[][]{b0, b3, t3, t0, null};
        f[3] = new float[][]{b2, b1, t1, t2, null};
        f[4] = new float[][]{t0, t1, t2, t3, null};
        f[5] = new float[][]{b0, b1, b2, b3, null};
        for (float[][] face : f) face[4] = sub(avg(face[0], face[1], face[2], face[3]), ctr);
        return f;
    }

    private static void face(float[][] f, int part, float s0, float s1, float t0, float t1, float push, float cell) {
        patch(f[0], f[1], f[2], f[3], part, s0, s1, t0, t1, push, f[4], cell);
    }

    private static void patch(float[] c00, float[] c10, float[] c11, float[] c01, int part,
                              float s0, float s1, float t0, float t1, float push, float[] hint, float cell) {
        float tm = (t0 + t1) / 2f, sm = (s0 + s1) / 2f;
        float lenS = dist(pt(c00, c10, c11, c01, s0, tm), pt(c00, c10, c11, c01, s1, tm));
        float lenT = dist(pt(c00, c10, c11, c01, sm, t0), pt(c00, c10, c11, c01, sm, t1));
        int nu = Math.max(1, Math.round(lenS / cell));
        int nv = Math.max(1, Math.round(lenT / cell));
        float[] pn = norm(cross(sub(c10, c00), sub(c01, c00)));
        if (dot(pn, hint) < 0) for (int i = 0; i < 3; i++) pn[i] = -pn[i];
        boolean glass = part >= WIN_FRONT && part <= WIN_RIGHT;
        for (int i = 0; i < nu; i++) {
            for (int j = 0; j < nv; j++) {
                float sa = s0 + (s1 - s0) * i / nu, sb = s0 + (s1 - s0) * (i + 1) / nu;
                float ta = t0 + (t1 - t0) * j / nv, tb = t0 + (t1 - t0) * (j + 1) / nv;
                float[] ss = {sa, sb, sb, sa}, tt = {ta, ta, tb, tb};
                float[] q = new float[12], uv = new float[8];
                for (int k = 0; k < 4; k++) {
                    float[] p = pt(c00, c10, c11, c01, ss[k], tt[k]);
                    for (int a = 0; a < 3; a++) q[k * 3 + a] = p[a] + pn[a] * push;
                    uv[k * 2] = glass ? (ss[k] - s0) / (s1 - s0) : 0.5f;
                    uv[k * 2 + 1] = glass ? (tt[k] - t0) / (t1 - t0) : 0.5f;
                }
                float[] n = quadNormal(q);
                if (dot(n, hint) < 0) for (int a = 0; a < 3; a++) n[a] = -n[a];
                POS_L.add(q); UV_L.add(uv); N_L.add(n); PART_L.add(part);
            }
        }
    }

    /** Normal of a quad from its diagonals (not oriented). */
    public static float[] quadNormal(float[] q) {
        float[] d1 = {q[6] - q[0], q[7] - q[1], q[8] - q[2]};
        float[] d2 = {q[9] - q[3], q[10] - q[4], q[11] - q[5]};
        return norm(cross(d1, d2));
    }

    // ------------------------------------------------------------------ tiny vector helpers

    private static float[] v(float x, float y, float z) { return new float[]{x, y, z}; }
    private static float[] sub(float[] a, float[] b) { return new float[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
    private static float dot(float[] a, float[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
    private static float dist(float[] a, float[] b) { float[] d = sub(a, b); return (float) Math.sqrt(dot(d, d)); }

    private static float[] cross(float[] a, float[] b) {
        return new float[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static float[] norm(float[] a) {
        float l = (float) Math.sqrt(dot(a, a));
        if (l < 1e-8f) return new float[]{0, 1, 0};
        return new float[]{a[0] / l, a[1] / l, a[2] / l};
    }

    private static float[] avg(float[]... ps) {
        float[] r = new float[3];
        for (float[] p : ps) for (int i = 0; i < 3; i++) r[i] += p[i] / ps.length;
        return r;
    }

    private static float[] pt(float[] a, float[] b, float[] c, float[] d, float s, float t) {
        float[] r = new float[3];
        for (int i = 0; i < 3; i++)
            r[i] = (1 - s) * (1 - t) * a[i] + s * (1 - t) * b[i] + s * t * c[i] + (1 - s) * t * d[i];
        return r;
    }
}
