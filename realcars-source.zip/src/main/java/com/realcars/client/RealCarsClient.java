package com.realcars.client;

import com.realcars.CarEntity;
import com.realcars.CarInputPayload;
import com.realcars.RealCarsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;

public class RealCarsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RealCarsMod.CAR, CarRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientPlayerEntity p = client.player;
            if (p != null && p.getVehicle() instanceof CarEntity) {
                GameOptions o = client.options;
                float throttle = (o.forwardKey.isPressed() ? 1f : 0f) - (o.backKey.isPressed() ? 1f : 0f);
                float steer = (o.leftKey.isPressed() ? 1f : 0f) - (o.rightKey.isPressed() ? 1f : 0f);
                ClientPlayNetworking.send(new CarInputPayload(throttle, steer, o.jumpKey.isPressed()));
            }
        });
    }
}
