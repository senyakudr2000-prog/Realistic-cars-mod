package com.realcars;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class CarEntity extends Entity {
    private static final TrackedData<String> DENTS = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.STRING);
    private static final TrackedData<Integer> GLASS = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> COLOR = DataTracker.registerData(CarEntity.class, TrackedDataHandlerRegistry.INTEGER);

    // physics tuning (blocks / tick)
    private static final double MAX_SPEED = 0.85, MAX_REV = 0.20;
    private static final double ACCEL = 0.014, BRAKE = 0.035, REV_ACCEL = 0.008;
    private static final int MAX_IMPACTS = 40;

    // server state
    private final List<Impact> impacts = new ArrayList<>();
    private double speed;
    private float inThrottle, inSteer;
    private boolean inBrake, hopNext;
    private int lastInputAge = -100;

    // client state
    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw;
    public float wheelAngle, prevWheelAngle, steerVis, prevSteerVis;
    private float[] deformed;
    private String deformedFor;

    public CarEntity(EntityType<? extends CarEntity> type, World world) {
        super(type, world);
    }

    // ------------------------------------------------------------------ data

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(DENTS, "");
        builder.add(GLASS, 0);
        builder.add(COLOR, 0xC62828);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        impacts.clear();
        impacts.addAll(Impact.parse(nbt.getString("Dents")));
        syncDents();
        dataTracker.set(GLASS, nbt.getInt("Glass"));
        if (nbt.contains("Color")) dataTracker.set(COLOR, nbt.getInt("Color"));
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putString("Dents", Impact.write(impacts));
        nbt.putInt("Glass", dataTracker.get(GLASS));
        nbt.putInt("Color", dataTracker.get(COLOR));
    }

    public int getColor() { return dataTracker.get(COLOR); }
    public void setColor(int rgb) { dataTracker.set(COLOR, rgb); }

    /** 0 = intact, 1 = cracked, 2 = shattered. Windows: 0 front, 1 rear, 2 left, 3 right. */
    public int getGlassLevel(int window) { return (dataTracker.get(GLASS) >> (window * 2)) & 3; }

    private boolean raiseGlass(int window, int level) {
        int g = dataTracker.get(GLASS);
        int cur = (g >> (window * 2)) & 3;
        if (level <= cur) return false;
        g = (g & ~(3 << (window * 2))) | (level << (window * 2));
        dataTracker.set(GLASS, g);
        return true;
    }

    private void syncDents() { dataTracker.set(DENTS, Impact.write(impacts)); }

    /** Client: deformed vertex positions (cached until the dent data changes). */
    public float[] getDeformedMesh() {
        String s = dataTracker.get(DENTS);
        if (deformed == null || !s.equals(deformedFor)) {
            deformed = CarMesh.deform(Impact.parse(s));
            deformedFor = s;
        }
        return deformed;
    }

    public void setInput(float throttle, float steer, boolean brake) {
        this.inThrottle = MathHelper.clamp(throttle, -1f, 1f);
        this.inSteer = MathHelper.clamp(steer, -1f, 1f);
        this.inBrake = brake;
        this.lastInputAge = age;
    }

    // ------------------------------------------------------------------ entity behaviour

    @Override public boolean isCollidable() { return true; }
    @Override public boolean canHit() { return !isRemoved(); }
    @Override protected boolean canAddPassenger(Entity passenger) { return getPassengerList().size() < 2; }

    @Override
    protected Vec3d getPassengerAttachmentPos(Entity passenger, EntityDimensions dimensions, float scaleFactor) {
        int idx = getPassengerList().indexOf(passenger);
        return new Vec3d(idx <= 0 ? 0.38 : -0.38, 0.8, 0.05);
    }

    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        World w = getWorld();
        if (stack.isOf(Items.IRON_INGOT) && !impacts.isEmpty()) {          // beat out the dents
            if (!w.isClient) {
                impacts.forEach(i -> i.depth *= 0.6f);
                impacts.removeIf(i -> i.depth < 0.04f);
                syncDents();
                if (!player.getAbilities().creativeMode) stack.decrement(1);
                w.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_ANVIL_USE, SoundCategory.NEUTRAL, 0.6f, 1.4f);
            }
            return w.isClient ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }
        if (stack.isOf(Items.GLASS_PANE) && dataTracker.get(GLASS) != 0) {  // replace glass
            if (!w.isClient) {
                dataTracker.set(GLASS, 0);
                if (!player.getAbilities().creativeMode) stack.decrement(1);
                w.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_GLASS_PLACE, SoundCategory.NEUTRAL, 1f, 1f);
            }
            return w.isClient ? ActionResult.SUCCESS : ActionResult.CONSUME;
        }
        if (!w.isClient) return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
        return ActionResult.SUCCESS;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (isRemoved()) return false;
        if (getWorld().isClient) return true;
        if (source.getAttacker() instanceof PlayerEntity p && (p.isSneaking() || p.getAbilities().creativeMode)) {
            if (!p.getAbilities().creativeMode) dropStack(new ItemStack(RealCarsMod.CAR_ITEM));
            discard();
        }
        return true;
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (DENTS.equals(data)) deformedFor = null;
    }

    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
        lerpX = x; lerpY = y; lerpZ = z; lerpYaw = yaw;
        lerpSteps = Math.max(1, interpolationSteps);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) clientTick(); else serverTick();
    }

    private void clientTick() {
        if (lerpSteps > 0) {
            double nx = getX() + (lerpX - getX()) / lerpSteps;
            double ny = getY() + (lerpY - getY()) / lerpSteps;
            double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
            float nyaw = getYaw() + MathHelper.wrapDegrees(lerpYaw - getYaw()) / lerpSteps;
            lerpSteps--;
            setPosition(nx, ny, nz);
            setRotation(nyaw, 0f);
        }
        double rad = Math.toRadians(getYaw());
        double dist = (getX() - prevX) * -Math.sin(rad) + (getZ() - prevZ) * Math.cos(rad);
        prevWheelAngle = wheelAngle;
        wheelAngle += (float) (dist / 0.34 * 57.29578);
        prevSteerVis = steerVis;
        float dyaw = MathHelper.wrapDegrees(getYaw() - prevYaw);
        steerVis += (MathHelper.clamp(-dyaw * 7f, -30f, 30f) - steerVis) * 0.35f;
    }

    private void serverTick() {
        Entity driver = getFirstPassenger();
        float throttle = 0, steer = 0;
        boolean brake = false;
        if (driver instanceof PlayerEntity && age - lastInputAge <= 5) {
            throttle = inThrottle; steer = inSteer; brake = inBrake;
        }

        boolean ground = isOnGround();
        if (ground) {
            if (throttle > 0) speed += speed < -0.02 ? BRAKE : ACCEL * (1 - Math.max(0, speed) / MAX_SPEED);
            else if (throttle < 0) speed -= speed > 0.02 ? BRAKE : REV_ACCEL;
            if (brake) speed *= 0.82;
            speed *= throttle == 0 ? 0.975 : 0.992;
            if (Math.abs(speed) < 0.004 && throttle == 0) speed = 0;
        } else {
            speed *= 0.999;
        }
        if (isTouchingWater()) speed *= 0.9;
        speed = MathHelper.clamp(speed, -MAX_REV, MAX_SPEED);

        if (ground) {
            setYaw(getYaw() - steer * (float) (speed * 16.0 / (1.0 + Math.abs(speed) * 2.5)));
        }

        double rad = Math.toRadians(getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);

        double vy = getVelocity().y;
        if (isTouchingWater()) vy = Math.min(vy + 0.02, 0.05);
        else if (ground) vy = -0.04;
        else vy = (vy - 0.08) * 0.98;
        if (hopNext) { vy = 0.42; hopNext = false; }

        Vec3d intended = new Vec3d(fx * speed, vy, fz * speed);
        double bx = getX(), bz = getZ();
        setVelocity(intended);
        move(MovementType.SELF, intended);

        if (horizontalCollision) {
            double lx = fx * speed - (getX() - bx), lz = fz * speed - (getZ() - bz);
            double lost = Math.sqrt(lx * lx + lz * lz);
            if (lost > 0.01) {
                double nx = lx / lost, nz = lz / lost;
                boolean stepUp = ground && lost < 0.35
                        && getWorld().isSpaceEmpty(this, getBoundingBox().offset(nx * 0.35, 1.05, nz * 0.35));
                if (stepUp) {
                    hopNext = true;                       // low obstacle: climb it
                } else {
                    double along = lx * fx + lz * fz;
                    double sev = MathHelper.clamp((lost - 0.10) / 0.55, 0.0, 1.4);
                    if (sev > 0) {
                        registerCrash(nx, nz, sev);
                        crashOtherCars(nx, nz, sev, lost);
                    }
                    speed -= along * (sev > 0.2 ? 1.3 : 1.0);
                }
            }
        }

        if (Math.abs(speed) > 0.2) hitEntities(fx, fz);
    }

    private void hitEntities(double fx, double fz) {
        List<LivingEntity> list = getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(0.15),
                e -> e.isAlive() && !hasPassenger(e) && e.getVehicle() != this);
        for (LivingEntity e : list) {
            e.damage(getDamageSources().generic(), (float) (Math.abs(speed) * 18.0));
            e.addVelocity(fx * speed * 1.1, 0.35, fz * speed * 1.1);
            e.velocityModified = true;
            speed *= 0.93;
        }
    }

    private void crashOtherCars(double dirX, double dirZ, double sev, double lost) {
        List<CarEntity> others = getWorld().getEntitiesByClass(CarEntity.class, getBoundingBox().expand(0.2), e -> e != this);
        for (CarEntity o : others) {
            double ox = o.getX() - getX(), oz = o.getZ() - getZ();
            double len = Math.hypot(ox, oz);
            if (len < 1e-3) continue;
            if ((ox / len) * dirX + (oz / len) * dirZ > 0.2) {
                o.registerCrash(-dirX, -dirZ, sev * 0.9);
                o.kick(dirX * lost * 0.8, dirZ * lost * 0.8);
            }
        }
    }

    /** Add world-space momentum to this car (projected on its forward axis). */
    public void kick(double ix, double iz) {
        double rad = Math.toRadians(getYaw());
        speed += ix * -Math.sin(rad) + iz * Math.cos(rad);
    }

    /**
     * @param dirX,dirZ unit world direction from the car's centre toward what it hit
     * @param sev       crash severity, ~0.1 (tap) .. 1.4 (full-speed wall)
     */
    public void registerCrash(double dirX, double dirZ, double sev) {
        World w = getWorld();
        if (w.isClient) return;

        double yr = Math.toRadians(getYaw());
        double cs = Math.cos(yr), sn = Math.sin(yr);
        double lx = dirX * cs + dirZ * sn;
        double lz = -dirX * sn + dirZ * cs;

        double kx = Math.abs(lx) < 1e-4 ? 1e9 : CarMesh.HALF_W / Math.abs(lx);
        double kz = Math.abs(lz) < 1e-4 ? 1e9 : CarMesh.HALF_L / Math.abs(lz);
        boolean frontBack = kz <= kx;
        double k = Math.min(kx, kz);
        float px = (float) (lx * k), pz = (float) (lz * k);
        if (frontBack) px += (random.nextFloat() - 0.5f) * 0.7f;
        else pz += (random.nextFloat() - 0.5f) * 1.2f;
        px = MathHelper.clamp(px, -CarMesh.HALF_W, CarMesh.HALF_W);
        pz = MathHelper.clamp(pz, -CarMesh.HALF_L, CarMesh.HALF_L);
        float py = 0.62f + (random.nextFloat() - 0.5f) * 0.35f;

        float depth = (float) Math.min(0.55, 0.07 + sev * 0.36);
        float radius = (float) (0.45 + sev * 0.55);
        float idx = (float) -lx, idz = (float) -lz;
        addImpact(new Impact(px, py, pz, idx, 0f, idz, depth, radius, random.nextFloat() * 100f));
        if (sev > 0.5) {
            float ox = frontBack ? 0.4f : 0f, oz = frontBack ? 0f : 0.5f;
            addImpact(new Impact(px + ox, py, pz + oz, idx, 0f, idz, depth * 0.5f, radius * 0.7f, random.nextFloat() * 100f));
            addImpact(new Impact(px - ox, py, pz - oz, idx, 0f, idz, depth * 0.5f, radius * 0.7f, random.nextFloat() * 100f));
        }

        boolean glassBroke = false;
        for (int wi = 0; wi < 4; wi++) {
            float[] c = CarMesh.WINDOW_CENTER[wi];
            double d = Math.sqrt(sq(c[0] - px) + sq(c[1] - py) + sq(c[2] - pz));
            double reach = 0.7 + sev * 1.5;
            if (d < reach) {
                double strength = sev * (1.5 - d / reach);
                int lvl = strength > 0.8 ? 2 : strength > 0.22 ? 1 : 0;
                if (lvl > 0 && raiseGlass(wi, lvl)) glassBroke = true;
            }
        }

        double wx = getX() + px * cs - pz * sn, wy = getY() + py, wz = getZ() + px * sn + pz * cs;
        w.playSound(null, wx, wy, wz, SoundEvents.ENTITY_IRON_GOLEM_DAMAGE, SoundCategory.NEUTRAL, (float) (0.8 + sev), 0.5f);
        if (sev > 0.5) w.playSound(null, wx, wy, wz, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.NEUTRAL, 0.7f, 0.6f);
        if (glassBroke) w.playSound(null, wx, wy, wz, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.NEUTRAL, 1.2f, 1f);
        if (w instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.CRIT, wx, wy, wz, (int) (6 + sev * 14), 0.25, 0.25, 0.25, 0.3);
            if (sev > 0.6) sw.spawnParticles(ParticleTypes.LARGE_SMOKE, wx, wy + 0.3, wz, 6, 0.3, 0.2, 0.3, 0.02);
            if (glassBroke) sw.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.GLASS.getDefaultState()),
                    getX(), getY() + 1.4, getZ(), 24, 0.5, 0.3, 0.5, 0.1);
        }

        if (sev > 0.35) {
            for (Entity p : getPassengerList()) p.damage(getDamageSources().flyIntoWall(), (float) ((sev - 0.3) * 14.0));
        }
    }

    private void addImpact(Impact n) {
        for (Impact o : impacts) {
            float a = o.x - n.x, b = o.y - n.y, c = o.z - n.z;
            if (a * a + b * b + c * c < 0.12f && (o.dx * n.dx + o.dy * n.dy + o.dz * n.dz) > 0.5f) {
                o.depth = Math.min(0.7f, o.depth + n.depth * 0.6f);
                o.radius = Math.max(o.radius, n.radius);
                syncDents();
                return;
            }
        }
        if (impacts.size() >= MAX_IMPACTS) {
            Impact weakest = impacts.get(0);
            for (Impact i : impacts) if (i.depth < weakest.depth) weakest = i;
            impacts.remove(weakest);
        }
        impacts.add(n);
        syncDents();
    }

    private static double sq(double v) { return v * v; }
}
