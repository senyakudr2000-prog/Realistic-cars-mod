package com.realcars;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** One dent: position/direction in car-local space, depth and radius in blocks. */
public final class Impact {
    public float x, y, z;
    public float dx, dy, dz;
    public float depth, radius, seed;

    public Impact(float x, float y, float z, float dx, float dy, float dz, float depth, float radius, float seed) {
        this.x = x; this.y = y; this.z = z;
        this.dx = dx; this.dy = dy; this.dz = dz;
        this.depth = depth; this.radius = radius; this.seed = seed;
    }

    public static String write(List<Impact> list) {
        StringBuilder sb = new StringBuilder();
        for (Impact i : list) {
            sb.append(String.format(Locale.ROOT, "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.1f;",
                    i.x, i.y, i.z, i.dx, i.dy, i.dz, i.depth, i.radius, i.seed));
        }
        return sb.toString();
    }

    public static List<Impact> parse(String s) {
        List<Impact> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String part : s.split(";")) {
            if (part.isEmpty()) continue;
            String[] f = part.split(",");
            if (f.length < 9) continue;
            try {
                out.add(new Impact(p(f[0]), p(f[1]), p(f[2]), p(f[3]), p(f[4]), p(f[5]), p(f[6]), p(f[7]), p(f[8])));
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    private static float p(String s) {
        return Float.parseFloat(s);
    }
}
